package com.rajesh.motivation

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.Locale

private val Navy = Color(0xFF172554)
private val Gold = Color(0xFFFDE68A)
private data class Story(val title: String, val category: String, val body: String)

private val sampleStories = listOf(
    Story("मेहनत की जीत", "प्रेरणा • 3 मिनट", "रवि एक गरीब लड़का था। उसके पास साधन कम थे, लेकिन सपने बड़े थे। वह रोज़ मेहनत से पढ़ाई करता और असफल होने पर भी कोशिश नहीं छोड़ता। एक दिन उसने परीक्षा में पहला स्थान प्राप्त किया। उसकी मेहनत ने साबित कर दिया कि सच्ची लगन से मुश्किल रास्ते भी आसान हो जाते हैं। सीख: आपकी मेहनत एक दिन आपकी पहचान बनेगी।"),
    Story("आखिरी कोशिश", "हिम्मत • 2 मिनट", "एक पर्वतारोही कई बार पहाड़ पर चढ़ने में असफल हुआ। हर बार वह अपनी गलती से सीखता और फिर कोशिश करता। आखिरकार वह शिखर तक पहुँच गया। उसने कहा, जीत उस दिन शुरू होती है जब हम हार मानने से इनकार कर देते हैं।"),
    Story("छोटा दीपक", "आत्मविश्वास • 2 मिनट", "अँधेरे कमरे में एक छोटा दीपक जल उठा। उसकी रोशनी बहुत बड़ी नहीं थी, फिर भी उसने आसपास का अँधेरा कम कर दिया। याद रखिए, आपकी छोटी शुरुआत भी बड़ा बदलाव ला सकती है।")
)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.getDefault()
                }
            }
        }
        setContent { RajeshApp(onSpeak = { speak(it) }) }
    }

    private fun speak(text: String) {
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rajesh_story")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun RajeshApp(onSpeak: (String) -> Unit) {
    var selected by remember { mutableIntStateOf(0) }
    val titles = listOf("होम", "कहानियाँ", "वीडियो", "बनाएं")
    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        bottomBar = {
            NavigationBar {
                val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.PlayCircle, Icons.Default.AutoAwesome)
                titles.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { selected = index },
                        icon = { Icon(icons[index], contentDescription = title) },
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { padding ->
        when (selected) {
            0 -> HomeScreen(Modifier.padding(padding), onSpeak) { selected = 1 }
            1 -> StoriesScreen(Modifier.padding(padding), onSpeak)
            2 -> VideosScreen(Modifier.padding(padding))
            else -> CreateScreen(Modifier.padding(padding), onSpeak)
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, onSpeak: (String) -> Unit, openStories: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Box(
            Modifier.fillMaxWidth().background(
                Brush.linearGradient(listOf(Navy, Color(0xFF1D4ED8))),
                RoundedCornerShape(24.dp)
            ).padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("RAJESH MOTIVATION", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("सपने बड़े रखो,\nमेहनत उससे भी बड़ी करो!", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("Stories • Motivation • Hindi Voice", color = Color.White.copy(alpha = .85f))
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("आज का विचार", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7D6))) {
            Column(Modifier.padding(18.dp)) {
                Text("“हार मत मानो, क्योंकि शुरुआत हमेशा मुश्किल होती है।”", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { onSpeak("हार मत मानो, क्योंकि शुरुआत हमेशा मुश्किल होती है।") }) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null)
                    Text(" सुनें")
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("कहानियाँ आपके लिए", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        sampleStories.forEach { story ->
            Card(Modifier.fillMaxWidth().padding(top = 9.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(story.title, fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
                    Text(story.category, color = Color.Gray, fontSize = 12.sp)
                    Text(story.body.take(105) + "…")
                    TextButton(onClick = { openStories() }) { Text("सभी कहानियाँ देखें") }
                }
            }
        }
    }
}

@Composable
fun StoriesScreen(modifier: Modifier, onSpeak: (String) -> Unit) {
    var expanded by remember { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("हिंदी मोटिवेशनल कहानियाँ", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(12.dp))
        sampleStories.forEachIndexed { index, story ->
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(story.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Text(story.category, color = Color.Gray, fontSize = 12.sp)
                    if (expanded == index + 1) {
                        Text(story.body, fontSize = 16.sp, lineHeight = 25.sp, modifier = Modifier.padding(top = 10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { onSpeak(story.body) }) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null)
                                Text(" कहानी सुनें")
                            }
                            TextButton(onClick = { expanded = 0 }) { Text("बंद करें") }
                        }
                    } else {
                        Text(story.body.take(95) + "…", modifier = Modifier.padding(top = 8.dp))
                        TextButton(onClick = { expanded = index + 1 }) { Text("पूरी कहानी पढ़ें") }
                    }
                }
            }
        }
    }
}

@Composable
fun VideosScreen(modifier: Modifier) {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoUri = uri
        }
    }
    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(it))
                prepare()
                playWhenReady = false
            }
        }
    }
    DisposableEffect(player) {
        onDispose { player?.release() }
    }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("मोटिवेशनल वीडियो", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.VideoLibrary, contentDescription = null)
            Text("  फोन से वीडियो चुनें")
        }
        if (player != null) {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                modifier = Modifier.fillMaxWidth().height(230.dp).padding(top = 14.dp)
            )
        } else {
            Card(Modifier.fillMaxWidth().padding(top = 14.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Icon(Icons.Default.PlayCircle, contentDescription = null, tint = Navy, modifier = Modifier.size(54.dp))
                    Text("अपना वीडियो यहाँ चलाएँ", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("ऊपर दिए बटन से अपने मोबाइल का MP4 या अन्य वीडियो चुनें।")
                }
            }
        }
        Text("नोट: इस संस्करण में मोबाइल से चुने गए वीडियो चलेंगे। कहानी से अपने आप नया MP4 वीडियो बनाने के लिए अगला क्लाउड AI वीडियो कनेक्शन चाहिए।",
            color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
fun CreateScreen(modifier: Modifier, onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var story by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("अपनी कहानी बनाएं", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("कहानी का नाम") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = story, onValueChange = { story = it }, label = { Text("अपनी हिंदी कहानी लिखें") }, modifier = Modifier.fillMaxWidth().height(180.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (story.isNotBlank()) onSpeak(story) }, modifier = Modifier.fillMaxWidth(), enabled = story.isNotBlank()) {
            Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
            Text("  कहानी की आवाज़ सुनें")
        }
        OutlinedButton(
            onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title.ifBlank { "मेरी मोटिवेशनल कहानी" })
                    putExtra(Intent.EXTRA_TEXT, "${title}\n\n${story}")
                }
                context.startActivity(Intent.createChooser(send, "कहानी शेयर करें"))
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = story.isNotBlank()
        ) {
            Icon(Icons.Default.Share, contentDescription = null)
            Text("  कहानी शेयर करें")
        }
        Text("यह संस्करण फोन की उपलब्ध हिंदी Text-to-Speech आवाज़ का उपयोग करता है। AI क्लाउड आवाज़ और कहानी से MP4 वीडियो बनाने के लिए API सेवा जोड़ना आवश्यक है।",
            color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    }
}
